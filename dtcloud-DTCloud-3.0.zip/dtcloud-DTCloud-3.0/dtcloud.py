#!/usr/bin/env python3

#  在导入时间模块之前，将服务器时区设置为UTC
__import__('os').environ['TZ'] = 'UTC'
import dtcloud

if __name__ == "__main__":
    dtcloud.cli.main()
