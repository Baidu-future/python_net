


(function () {
    // window.layoutHelpers.setAutoUpdate(true);
    // window.attachMaterialRippleOnLoad();
    // $('[data-toggle="popover"]').popover();
    // $('[data-toggle="tooltip"]').tooltip();
    // $('[data-toggle="tooltip"]').on('inserted.bs.tooltip', function () {
    //     $('.tooltip').addClass('tooltip-' + $(this).attr('data-state'));
    // })
    // $('[data-toggle="popover"]').on('inserted.bs.popover', function () {
    //     $('.popover').addClass('popover-' + $(this).attr('data-state'));
    // })
    // active menu item list start

function GetRequest(valUrl) {
//        var url = window.location.href; //获取url中"?"符后的字串
        var url = valUrl; //获取url中"?"符后的字串
        var theRequest = new Object();
        if (url.indexOf("#") != -1) {
            let str = url.substr(1);

            strs = str.split("&");
            for (var i = 0; i < strs.length; i++) {
                theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
            }
        }

       return theRequest;
    }

//    document.getElementById("miao_"+GetRequest()["menu_id"]+"").scrollIntoView();
    $("#layout-sidenav .sidenav-inner a").each(function () {

        let action_id=''

       let locationUrl = GetRequest(window.location.href);
       let location_id = GetRequest(window.location.href).menu_id;

        if(GetRequest(this.href).model==='ir.actions.act_window' && this.href.split(/[?#]/)[1].split(/[?&]/)[0].split(/[?=]/)[1]===location_id && window.location.href.split(/[?#]/)[1].split(/[?&]/)[0].split(/[?=]/)[1]=== GetRequest(this.href).action){
         $(this).parent('li').addClass("active");
            $(this).parent('li').parent().parent('.sidenav-item').addClass("active");
            $(this).parent('li').parent().parent('.sidenav-item').addClass("open");
            $(this).parent('li').parent().parent().parent().parent('.sidenav-item').addClass("active");
            $(this).parent('li').parent().parent().parent().parent('.sidenav-item').addClass("open");
            $(this).parent('li').parent().parent().parent().parent().parent().parent('.sidenav-item').addClass("active");
            $(this).parent('li').parent().parent().parent().parent().parent().parent('.sidenav-item').addClass("open");
        };
    });


    $("#layout-sidenav .sidenav-inner a").on('click',function (e) {
         $("#layout-sidenav .sidenav-inner .sidenav-item").removeClass('active')
          e.currentTarget.parentNode.classList.add("active")
    });

})();


// 折叠菜单
(function () {

    if ($('#layout-sidenav').hasClass('sidenav-horizontal') || window.layoutHelpers.isSmallScreen()) {

        return;
    }


    try {
        window.layoutHelpers.setCollapsed(
            localStorage.getItem('layoutCollapsed') === 'true',
            false
        );
    } catch (e) {
    }
})();

$(function () {
    // Initialize sidenav
    $('#layout-sidenav').each(function () {
        new SideNav(this, {
            orientation: $(this).hasClass('sidenav-horizontal') ? 'horizontal' : 'vertical'
        });
    });

    // Initialize sidenav togglers
    $('body').on('click', '.layout-sidenav-toggle', function (e) {
        // console.log(e.hasClass('sidenav-horizontal'))
        if (window.layoutHelpers.isCollapsed() == false) {
            $("#o_navbar_search").width(52.5)
        } else {

            $("#o_navbar_search").width(187.5)
        }

        e.preventDefault();
        window.layoutHelpers.toggleCollapsed();
        if (!window.layoutHelpers.isSmallScreen()) {
            try {
                localStorage.setItem('layoutCollapsed', String(window.layoutHelpers.isCollapsed()));
            } catch (e) {
            }
        }

    });
});

$(function () {
    // ***********************************************************
    // Menu Customizer Start

    // open Menu Styler
    $('#ui-builder > .style-toggler').on('click', function () {
        $('#ui-builder').toggleClass('open');
    });

    $('.layout-reset').on('click', function () {
        location.reload();
    });

    // nav-fixed Fixed
    $('#nav-fixed').change(function () {
        if ($(this).is(":checked")) {
            $('html').addClass('layout-fixed');
        } else {
            $('html').removeClass('layout-fixed');
        }
    });

    // header Fixed
    $('#header-fixed').change(function () {
        if ($(this).is(":checked")) {
            $('html').addClass('layout-header-fixed');
        } else {
            $('html').removeClass('layout-header-fixed');
        }
    });

    // Dark Layout
    $('#dark-layout').change(function () {
        if ($(this).is(":checked")) {
            $('head .style-link').attr("href", "/web2/static/templates/zh_CN/assets/css/style-dark.css");
            $('#layout-sidenav').removeClassPrefix('bg-');
            $('#layout-sidenav').addClass("bg-dark");
            $('#layout-navbar').removeClassPrefix('bg-');
            $('#layout-navbar').addClass("bg-dark");
            $('.layout-footer').removeClassPrefix('bg-');
            $('.layout-footer').addClass("bg-dark");
            theme("layout", true);

        } else {
            $('head .style-link').attr("href", "/web2/static/templates/zh_CN/assets/css/style.css");
            $('.layout-sidenav').removeClassPrefix('bg-');
            $('.layout-sidenav').addClass("bg-white");
            $('#layout-navbar').removeClassPrefix('bg-');
            $('#layout-navbar').addClass("bg-white");
            $('.layout-footer').removeClassPrefix('bg-');
            $('.layout-footer').addClass("bg-white");
            theme("layout", false);
        }
    });

    // Header Color
    $('.header-color > a').on('click', function () {
        debugger
        var temp = $(this).attr('data-val');
        $('#layout-navbar').removeClassPrefix('bg-');
        $('#layout-navbar').addClass(temp);

        theme("layout_header_color", temp);


    });
    // sidenav Color
    $('.sidenav-color > a').on('click', function () {
        var temp = $(this).attr('data-val');
        if (temp == "bg-white") {
            $('#layout-sidenav').addClass('sidenav-light');
            $('#layout-sidenav').removeClass('sidenav-dark');
        } else {
            $('#layout-sidenav').removeClass('sidenav-light');
            $('#layout-sidenav').addClass('sidenav-dark');
        }
        $('#layout-sidenav').removeClassPrefix('bg-');
        $('#layout-sidenav').addClass(temp);
        $('.sidenav').removeClassPrefix('bg-');
        $('.sidenav').addClass(temp);

        theme("layout_sidenav_color", temp);
    });
    // Footer Color
    $('.footer-color > a').on('click', function () {
        var temp = $(this).attr('data-val');
        $('.layout-footer').removeClassPrefix('bg-');
        $('.layout-footer').addClass(temp);

        theme("layout_footer_color", temp);
    });

    $.fn.removeClassPrefix = function (prefix) {
        this.each(function (i, it) {
            var classes = it.className.split(" ").map(function (item) {
                return item.indexOf(prefix) === 0 ? "" : item;
            });
            it.className = classes.join(" ");
        });
        return this;
    };
    // Menu Customizer End
    // ***************************************************


});

function theme(name, value) {
    var data = {
        "name": name,
        "value": value,
    }
    $.ajax({
        url: "/theme",
        data: data,
        type: "post",
        success: function (result) {
            var data = eval('(' + result + ')');

            debugger
            if (data['errmsg'] == 'ok') {
                // alert(data.data.o_list_button_html)

                // $("#o_list_button_box").prepend(data.data.o_list_button_html);
            } else {
            }
        },
        error: function () {
        }
    });
}

//div对象隐藏与显示
function div_display(id) {
    var traget = document.getElementById(id);
    if (traget.style.display == "none") {
        traget.style.display = "";
    } else {
        traget.style.display = "none";
    }
}

//列表日期格式化
function DateFormat(time_str, format) {
    Date.prototype.Format = function (fmt) {
        var o = {
            "M+": this.getMonth() + 1, //月份
            "d+": this.getDate(), //日
            "H+": this.getHours(), //小时
            "m+": this.getMinutes(), //分
            "s+": this.getSeconds(), //秒
            "q+": Math.floor((this.getMonth() + 3) / 3), //季度
            "S": this.getMilliseconds() //毫秒
        };
        if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
        for (var k in o)
            if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
        return fmt;
    }
    let d = new Date(time_str)
    return d.Format(format)
}

function many2one(input_str) {
    input_str = input_str.replace(/[\{\}\(\)"']/g, "")
    input_str = "," + input_str
    input_str = input_str.replace(/,[1-9]\d*,/g, ",")
    console.log(input_str)
    let in_arr = input_str.split(",")
    let style_arr = ["default", "primary", "secondary", "success", "info", "warning", "danger", "dark"]
    let style = ""
    let s_len = style_arr.length
    let index = 0
    for (v of in_arr) {
        if (v !== "") {
            let class_name = style_arr[index % s_len]
            style += `<span class="badge badge-${class_name} font-weight-normal ml-2">${v}</span>`
            index++
        }
    }
    console.log(style)
    return style
}

let toggle = 0;
let lastClick = 0;
$(document).on('keyup', function (e) {
    e = e || event;
    var keyCode = e.keyCode ? e.keyCode : e.which ? e.which : e.charCode;
    //根据最新时间戳和初始时间戳进行比对，得出时间差
    if (keyCode == 13) {
        var t = new Date().getTime()
        if (toggle >= 2 && t - lastClick < 500) {
            $('.o_main_navbar').find('input').focus()
            toggle = 0
        }
        lastClick = t;
        toggle++
    }
});



