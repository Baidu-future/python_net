# -*- coding: utf-8 -*-
# &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
# DTCloud v3.0
# QQ:35350428
# 邮件:35350428@qq.com
# 手机：13584935775
# 作者：'Amos'
# 公司网址： www.dtcloud360.com
# Copyright 中亿丰数字科技集团有限公司 2012-2025 Amos
# 日期：2022-06-08
# &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&


{
    'name': "DTCloud 风格",
    'summary': """""",
    'author': "Amos",
    'website': "",
    'category': '中台应用/风格',
    "application": True,
    'version': '0.1',
    "depends": ['web'],
    'price': '0',
    'currency': 'CNY',
    'judge': 'checked',
    'priority': '4',
    'data': [
        'views/dtcloud_style.xml',
    ],
    'description': """
    菜单侧边单显示
""",
    'application': False,
    'auto_install': True,
    'assets': {
        'web.assets_qweb': [

        ],
        'web.assets_backend': [
            'dtcloud_style/static/src/navbar/navbar.xml',
            'dtcloud_style/static/src/scss/style.scss',
            'dtcloud_style/static/src/scss/dtcloud_style.scss',
        ],

    },
    'license': 'LGPL-3',
}
