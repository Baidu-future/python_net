# -*- coding: utf-8 -*-
from datetime import date, timedelta

from dtcloud import _, api, fields, models
from dtcloud.exceptions import ValidationError


class go_upload_wizards(models.TransientModel):
    _name = 'go.upload.wizards'
    _description = '弹出上传界面'

    name = fields.Html(string='地址',default='')

    @api.model
    def default_get(self, fields):
       res = super(go_upload_wizards, self).default_get(fields)
       context = dict(self._context or {})

       html = """<!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8">
                    <title>Title</title>
                </head>
                <body>
                    <iframe src="%s" id="iframe1" width="700" height="300" frameborder="0" scrolling="auto"></iframe>
                </body>
                </html>""" % (context.get('default_name'))

       res.update({'name': html, })
       return res

    def get_view_form(self):
        return {
            'name': '上传附件',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'go.upload.wizards',
            'view_id': self.env.ref('core.go_upload_wizards_form').id,
            'type': 'ir.actions.act_window',
            'res_id': False,
            'context': [],
            'target': 'new'
        }





