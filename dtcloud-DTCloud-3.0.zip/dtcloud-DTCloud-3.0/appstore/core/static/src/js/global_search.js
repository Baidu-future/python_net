//全局条码查询
function global_search() {
    var params = {
        "keywords": $('#keywords').val().trim(),
    }

    $.ajax({
        url: "/s?",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        data: JSON.stringify(params),
        method: 'POST',
        success: function (result) {
            if (result.errmsg == 'ok') {
                window.location.href = "/web#model=" + result.data.res_model + "&id=" + result.data.res_id + "";
            } else {
                $.growl.notice({
                            title: '',
                            message:result.message,
                            duration: 2000
                        });
            }
        },
        error: function () {
        }
    });
    return false;
}
