import os



model_dirs = '/Users/amos/Documents/Gitee/DTCloud3/dtcloud/addons'
if os.path.isdir(model_dirs):
    dirs = os.listdir(model_dirs)



for modeldir in dirs:
    next_modeldir = model_dirs + "/" + modeldir
    if modeldir == '.DS_Store':
        pass
    elif modeldir in ['__init__.py', 'README.md', 'CONTRIBUTING.md','LICENSE','COPYRIGHT']:
        pass
    else:
        print(next_modeldir)
        models = os.listdir(next_modeldir)
        for model in models:
            if os.path.isdir(next_modeldir + "/" + model):
                if 'i18n' in os.listdir(next_modeldir):
                    i18ns = os.listdir(next_modeldir + "/i18n")
                    for i18n in i18ns:
                        if i18n != 'en_US.po' and i18n != 'zh_CN.po':
                            os.remove(next_modeldir + "/i18n/" + i18n)
                            print(next_modeldir)