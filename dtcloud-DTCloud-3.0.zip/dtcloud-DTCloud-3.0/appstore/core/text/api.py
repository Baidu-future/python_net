# encoding:utf-8
import requests

# 122.51.164.176:8069  正式服务器测试端口


url  = 'http://127.0.0.1:9099'

# # post 用户登陆
data = {
    'login': 'admin',
    'password': '1',
    'type': '0',  # 0：用帐号与密码登陆  1：手机验证码登陆  2，发送手机验证码，3：微信扫码登陆  4，APP验证码登陆
}
r = requests.post('%s/api/v1/login/0' % url, data=data)
print(r.text.encode('utf-8').decode('unicode_escape'))
v = eval(r.text)





# # post CMS新闻列表 公开查询
postdata = {
    'model': 'global.search',  # 当前对象
    'function_name': '_api_public_one',  # 返回一条记录

    'keywords': 'S00004',              #搜索 可选

}
r = requests.post('%s/api/v1/public_getattr/0' % url, data=postdata)
print(r.text.encode('utf-8').decode('unicode_escape'))

