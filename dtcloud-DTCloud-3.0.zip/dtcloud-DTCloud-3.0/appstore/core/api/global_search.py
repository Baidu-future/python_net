# -*- coding: utf-8 -*-
# &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
# DTCloud v3.0
# QQ:35350428
# 邮件:35350428@qq.com
# 手机：13584935775
# 作者：'Amos'
# 公司网址： www.dtcloud360.com
# Copyright 中亿丰数字科技集团有限公司 2012-2025 Amos
# 日期：2022-06-08
# &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&


from dtcloud import api, fields, models, tools, SUPERUSER_ID, _
from datetime import datetime, timedelta
from dtcloud import api, fields, models, _
from dtcloud.exceptions import UserError, ValidationError
from dtcloud.tools.misc import formatLang
from dtcloud.osv import expression
from dtcloud.tools import float_is_zero, float_compare
import dtcloud
import os
import ast

class global_search(models.Model):
    _inherit = "global.search"


    def _api_public_one(self, *kw):
        values = {}
        obj = self.sudo().search_read(['|',('barcode', '=', kw[0].get("keywords")),('partner_ref', '=', kw[0].get("keywords"))], ['menu_id','res_id','res_model','name','action','company_id'],order="id desc", limit=1)
        print(obj)
        if obj:
            values = {
                'name': obj[0]['name'],
                'menu_id': obj[0]['menu_id'],
                'res_id': obj[0]['res_id'],
                'res_model': obj[0]['res_model'],
                'action': obj[0]['action'],
                'company_id': obj[0]['company_id'],
            }

        data = {
            "errcode": 0,  # 错误码
            'errmsg': 'ok',
            'data': values,
            'message': '返回成功!'}
        return data