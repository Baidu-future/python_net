# -*- coding: utf-8 -*-
from dtcloud import api, fields, models, SUPERUSER_ID, _
from ctypes import *
import ctypes


class ir_http(models.AbstractModel):
    _inherit = "ir.http"
    #
    # def _api_interface(self, *kw):
    #     lib = cdll.LoadLibrary('main.so')
    #
    #     # 1,当前类库的版本号
    #     lib.version()
    #
    #     values = {
    #         'version': lib.version(),
    #     }
    #     data = {
    #         "errcode": 0,  # 错误码
    #         'errmsg': 'ok',
    #         'data': values,
    #         'message': '请求成功!'}
    #     return data
