# -*- coding: utf-8 -*-
# &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
# DTCloud v3.0
# QQ:35350428
# 邮件:35350428@qq.com
# 手机：13584935775
# 作者：'Amos'
# 公司网址： www.dtcloud360.com
# Copyright 中亿丰数字科技集团有限公司 2012-2025 Amos
# 日期：2022-06-08
# &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&


from dtcloud import api, fields, models, tools, SUPERUSER_ID, _
from dtcloud.exceptions import AccessError, UserError, ValidationError


class Partner(models.Model):
    _inherit = "res.partner"
    # 在联系人关联登陆帐号方便取用户的登陆ID
    login_id = fields.Many2one('res.users', compute='_compute_login_id', store=True, string='联系人关联帐号')

    @api.depends('user_ids')
    def _compute_login_id(self):
        for partner in self:
            if partner.user_ids:
                partner.login_id = partner.user_ids[0].id
            else:
                partner.login_id = False