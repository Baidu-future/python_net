# -*- coding: utf-8 -*-
# &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
# DTCloud v3.0
# QQ:35350428
# 邮件:35350428@qq.com
# 手机：13584935775
# 作者：'Amos'
# 公司网址： www.dtcloud360.com
# Copyright 中亿丰数字科技集团有限公司 2012-2025 Amos
# 日期：2022-06-08
# &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&


from dtcloud import models, api
from lxml.builder import E
from dtcloud.exceptions import UserError, ValidationError
import json

class BaseModel(models.AbstractModel):
    _inherit = 'base'

    # TODO(amos): 发短信
    def send_sms(self, kw):
        """
        发送短信
        :return:
        """
        data = {
            "errcode": -0,
            'errmsg': 'no',
            "data": '',
            'message': '没有安装短信模块!'}
        return json.dumps(data)

    # TODO(amos): 发邮件
    def send_email(self, kw):
        """
        发送短信
        :return:
        """
        data = {
            "errcode": -0,
            'errmsg': 'no',
            "data": '',
            'message': '没有安装配置邮件模块!'}
        return json.dumps(data)

    # TODO(amos): 发钉钉
    def send_ding(self, kw):
        """
        发送短信
        :return:
        """
        data = {
            "errcode": -0,
            'errmsg': 'no',
            "data": '',
            'message': '没有安装钉钉模块!'}
        return json.dumps(data)

    # TODO(amos): 发微信
    def send_wechat(self, kw):
        """
        发送短信
        :return:
        """
        data = {
            "errcode": -0,
            'errmsg': 'no',
            "data": '',
            'message': '没有安装企业微信模块!'}
        return json.dumps(data)
