# -*- coding: utf-8 -*-
# &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
# DTCloud v3.0
# QQ:35350428
# 邮件:35350428@qq.com
# 手机：13584935775
# 作者：'Amos'
# 公司网址： www.dtcloud360.com
# Copyright 中亿丰数字科技集团有限公司 2012-2025 Amos
# 日期：2022-06-08
# &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

import os
import dtcloud
from dtcloud import http, fields, _,tools
from dtcloud.http import request
from jinja2 import Environment, FileSystemLoader
import json

class global_search(http.Controller):



    @http.route(['/s'], type='http', auth="public",csrf=False)
    def s(self, **kw):
        """
        :param kw:
        :return:
        """
        cr, uid, context, pool = request.cr, request.session.uid, request.context, request.env
        params = json.loads(request.httprequest.data)
        values = []
        data = {
            "errcode": 0,  # 错误码
            'errmsg': 'ok',
            'data': values,
            'message': '返回成功!'}
        obj = pool['global.search'].sudo().search_read(['|',('barcode', '=', params.get("keywords")),('partner_ref', '=', params.get("keywords"))], ['menu_id','res_id','res_model','name','action'],order="id desc", limit=1)
        if obj:
            values = {
                'name': obj[0]['name'],
                'menu_id': obj[0]['menu_id'],
                'res_id': obj[0]['res_id'],
                'res_model': obj[0]['res_model'],
                'action': obj[0]['action'],
            }
            data['data'] = values
        else:
            data['errcode'] = -1
            data['errmsg'] = 'no'
            data['message'] = '未找到单据'

        return json.dumps(data, cls=tools.jinja_filters.DateEncoder)




    @http.route(['/icon'], type='http', auth="public",csrf=False)
    def icon(self, **kw):
        """
        :param kw:
        :return:
        """

        return request.redirect_query('/dtcloud_style/static/src/icon_feather.html')
