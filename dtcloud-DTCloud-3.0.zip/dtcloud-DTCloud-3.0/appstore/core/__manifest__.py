# -*- coding: utf-8 -*-
# &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
# DTCloud v3.0
# QQ:35350428
# 邮件:35350428@qq.com
# 手机：13584935775
# 作者：'Amos'
# 公司网址： www.dtcloud360.com
# Copyright 中亿丰数字科技集团有限公司 2012-2025 Amos
# 日期：2022-06-08
# &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&



{
    'name': '核心扩展',
    'version': '1.0',
    'category': '中台应用/底层',
    'summary': '功能说明',
    'sequence': 0,
    'author': 'Amos',
    'website': 'http://dtcloud360.com',
    'depends': ['base'],
    'data': [
        'security/ir.model.access.csv',
        'wizard/go_upload_wizards.xml'
    ],
    'demo': [
    ],
    'assets': {
        'web.assets_backend': [
            'core/static/src/scss/css.css',
            'core/static/src/js/jquery.growl.css',
            'core/static/src/js/jquery.growl.js',
            'core/static/src/js/global_search.js',
        ],
        'web.assets_tests': [
        ],
        'web.qunit_suite_tests': [
        ],
        'web.assets_qweb': [
        ],
    },
    'installable': True,
    'application': True,
    'auto_install': True,
    'license': 'LGPL-3',
    'description': """
    空API:短信
    """,
}
