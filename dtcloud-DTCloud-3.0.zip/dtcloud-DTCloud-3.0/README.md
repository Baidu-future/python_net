DTCloud V3.0
------------------

智能建造快速开发中台DTCloud是一套开源商业应用程序.主要面向建筑工程行业，物联网行业，数字化行业，打造的企业信息一体化的解决方案。

公司网站 <a href="http://www.dtcloud360.com">DTCloud开源社区</a>

如果你想进一步了解我们的系统可以观看 <a href="https://live.bilibili.com/23805516">DTCloud 直播</a>



DTCloud应用程序可以作为独立应用程序使用，也可以无缝集成其它应用系统。DTCloud可以开发ERP,OA,CRM,智慧城市,小程序等

DTCloud安装版本
------------------

Python3.7  QQ群号:195595623 内下载venv37 引用包

PostgreSQL 12


入门DTCloud开发
------------------

我们提供在线的教学网站与应用APP

<a href="https://docs.qq.com/doc/DRHVwbE1DdGR4dmVU">DTCloud开发教程</a>

<a href="https://docs.qq.com/doc/DVUhVenZvaUhTYmxj">DTCloud API</a>

<a href="http://www.dtcloud360.com">DTCloud开源社区</a>

DTCloud 脚手架
------------------
   创建工程文件夹 + 中文模块名 + 对象名称 +存放文件夹名称

python dtcloud.py scaffold amos_demo 销售 amos.demo appstore


![Image text](https://gitee.com/dtcloud360/dtcloud/raw/master/appstore/Amos_Install_Community/static/src/img/login.png)

![Image text](https://gitee.com/dtcloud360/dtcloud/raw/master/appstore/Amos_Install_Community/static/src/img/dtcloud.png)

![Image text](https://gitee.com/dtcloud360/dtcloud/raw/master/appstore/Amos_Install_Community/static/src/img/app.jpg)

![Image text](https://gitee.com/dtcloud360/dtcloud/raw/master/appstore/Amos_Install_Community/static/src/img/dtcloud2.png)

端口说明
------------------
DTCloud 9099 网站访问端口

DTCloud 9098 长连接

Upload 9097 上传文件端口

Preview_url 9096 文件附件预览接口

download_url 9095 文件下载接口

PostgreSQL 5432 数据库接口

Print 9091 套打打印端口

ZPL 9100 指令打印端口

GOAPI 10001 对外服务的接口

GO服务端口
------------------

community_websocket_http 9090 内制开源市场端口

socket 9090 本通讯接口 同 community_websocket_http

websocket_http 39.100.114.222:32771 长连接内制开源市场实时订单接口

go_port 9088 本通讯接口


目标群体
------------------

1. 软件公司
2. 学校教学
3. 个人应用开发者


#### 参与贡献

主要开发公司
------------------

✧ 中亿丰数字科技集团有限公司

✧ 中亿丰信息科技（苏州）有限公司


主要开发者
------------------
Amos,扶程星云,鲍丙军
