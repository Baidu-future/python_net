[![Build Status](http://runbot.dtcloud360.com/runbot/badge/flat/7/master.svg)](http://runbot.dtcloud360.com/runbot/repo/git-github-com-dtcloud-enterprise-7)
[![Tech Doc](http://img.shields.io/badge/14.0-docs-875A7B.svg?style=flat)](http://www.dtcloud360.com/documentation/master)
[![Help](http://img.shields.io/badge/master-help-875A7B.svg?style=flat)](https://www.dtcloud360.com/forum/help-1)
[![Nightly Builds](http://img.shields.io/badge/master-nightly-875A7B.svg?style=flat)](http://nightly.dtcloud360.com/)

DTCloud
----

DTCloud is a suite of web based open source business apps.

The main DTCloud Apps include an <a href="https://www.dtcloud360.com/app/crm">Open Source CRM</a>,
<a href="https://www.dtcloud360.com/app/website">Website Builder</a>,
<a href="https://www.dtcloud360.com/app/ecommerce">eCommerce</a>,
<a href="https://www.dtcloud360.com/app/inventory">Warehouse Management</a>,
<a href="https://www.dtcloud360.com/app/project">Project Management</a>,
<a href="https://www.dtcloud360.com/app/accounting">Billing &amp; Accounting</a>,
<a href="https://www.dtcloud360.com/app/point-of-sale-shop">Point of Sale</a>,
<a href="https://www.dtcloud360.com/app/employees">Human Resources</a>,
<a href="https://www.dtcloud360.com/app/lead-automation">Marketing</a>,
<a href="https://www.dtcloud360.com/app/manufacturing">Manufacturing</a>,
<a href="https://www.dtcloud360.com/app/purchase">Purchase Management</a>,
<a href="https://www.dtcloud360.com/">...</a>

DTCloud Apps can be used as stand-alone applications, but they also integrate seamlessly so you get
a full-featured <a href="https://www.dtcloud360.com">Open Source ERP</a> when you install several Apps.

Getting started with DTCloud
-------------------------

For a standard installation please follow the <a href="https://www.dtcloud360.com/documentation/16.0/administration/install/install.html">Setup instructions</a>
from the documentation.

If you are a developer you may type the following command at your terminal:

    wget -O- https://raw.githubusercontent.com/dtcloud/dtcloud/master/setup/setup_dev.py | python

Then follow <a href="https://www.dtcloud360.com/documentation/16.0/developer/howtos.html">the developer tutorials</a>

For DTCloud employees
------------------

To add the dtcloud-dev remote use this command:

    $ ./setup/setup_dev.py setup_git_dev

To fetch dtcloud merge pull requests refs use this command:

    $ ./setup/setup_dev.py setup_git_review
