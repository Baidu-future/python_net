/** @dtcloud-module **/

export const TEST_GROUP_IDS = {
    groupUserId: 11,
};

export const TEST_USER_IDS = {
    partnerRootId: 2,
    currentPartnerId: 3,
    currentUserId: 2,
    publicPartnerId: 4,
    publicUserId: 3,
};
