# -*- coding: utf-8 -*-
from . import bus
from . import bus_presence
from . import ir_http
from . import ir_model
from . import ir_websocket
from . import res_users
from . import res_partner
